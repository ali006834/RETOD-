import React from "react";

const svg = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="800px"
    height="800px"
    viewBox="0 0 24 24"
    fill="none"
  >
    <path
      d="M12 4V20M12 4L8 8M12 4L16 8"
      stroke="#222"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
);

export default svg;
