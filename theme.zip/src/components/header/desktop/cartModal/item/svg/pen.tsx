import React from "react";

const svg = () => (
  <svg
    role="presentation"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
  >
    <path
      d="M5 16L4 20L8 19L19.5858 7.41421C20.3668 6.63316 20.3668 5.36683 19.5858 4.58579L19.4142 4.41421C18.6332 3.63316 17.3668 3.63317 16.5858 4.41421L5 16Z"
      stroke="#000"
      stroke-width="1"
      stroke-linecap="round"
      stroke-linejoin="round"
    ></path>
    <path
      d="M15 6L18 9"
      stroke="#000"
      stroke-width="1"
      stroke-linecap="round"
      stroke-linejoin="round"
    ></path>
    <path
      d="M13 20H21"
      stroke="#000"
      stroke-width="1"
      stroke-linecap="round"
      stroke-linejoin="round"
    ></path>
  </svg>
);

export default svg;
