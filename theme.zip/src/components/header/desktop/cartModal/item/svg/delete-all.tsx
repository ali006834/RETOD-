import React from "react";

const svg = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="16px"
    height="16px"
    viewBox="0 0 24 24"
    fill="none"
  >
    <path d="M14.5 3H9.5L8.5 4H5V6H19V4H15.5L14.5 3Z" fill="#333" />
    <path
      d="M6 7H18V19C18 20.1 17.1 21 16 21H8C6.9 21 6 20.1 6 19V7Z"
      fill="#333"
    />
    <path d="M10 10H14V12H10V10Z" fill="white" />
    <path d="M10 13H14V15H10V13Z" fill="white" />
    <path d="M10 16H14V18H10V16Z" fill="white" />
  </svg>
);

export default svg;
