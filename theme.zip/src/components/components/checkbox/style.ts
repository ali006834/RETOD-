import styled, { css } from "styled-components";
import { FormItemStatus } from "../form/form-item";

type WrapperProps = {
  $status: FormItemStatus;
};

export const Wrapper = styled.label<WrapperProps>`
  position: relative;
  display: flex;
  align-items: center;

  ${({ $status, theme }) =>
    $status === "error" &&
    css`
      color: ${theme.color.red};
    `};
`;

export const CustomCheckboxInnerWrapper = styled.span<{ $mr: boolean }>`
  position: relative;
  display: inline-block;
  color: ${({ theme }) => theme.color.inputText};
  ${({ $mr }) => $mr && `margin-right: 8px;`}
`;

type CustomCheckboxProps = {
  $status: FormItemStatus;
  $radioStyle?: boolean;
  $checked?: boolean;
};

export const CustomCheckbox = styled.span<CustomCheckboxProps>`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 16px;
  height: 16px;
  padding: 2px;
  color: ${({ $checked, theme }) => ($checked ? "#fff" : theme.color.checkbox)};
  border: 1px solid #000;
  background-color: ${({ $checked, theme }) => ($checked ? "#000" : theme.color.checkboxBg)};

  ${({ $status, theme }) =>
    $status === "error" &&
    css`
      color: ${theme.color.red};
      border-color: ${theme.color.red};
    `};

  border-radius: ${({ $radioStyle }) => ($radioStyle ? "50%" : "0px")};
  cursor: pointer;
`;

export const RadioDot = styled.span`
  width: 8px;
  height: 8px;
  background-color: #fff;
  border-radius: 50%;
`;

export const HiddenCheckbox = styled.input`
  :hover + span,
  :focus-within + span {
    box-shadow: 0 0 0 2px rgb(0 0 0 / 10%);
    border-radius: 2px;
  }
`;
