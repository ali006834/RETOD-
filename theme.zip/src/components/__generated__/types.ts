import {
	IkasImage,
	IkasNavigationLink,
	IkasVideo,
	IkasProductList,
	IkasProduct,
	IkasSlider,
	IkasCategoryList,
	IkasBlogList,
	IkasBlog,
	IkasComponentRenderer,
} from "@ikas/storefront"

export type ScrollingTexts = { 
	content?: string;
};

export type BannerTopImage = { 
	imageCDT?: IkasImage;
	imageLink?: IkasNavigationLink;
	titleCDT?: string;
	contentCDT?: string;
	btnTextCDT?: string;
	priorityOrder?: string;
};

export type BannerTopVideo = { 
	videoCDT?: IkasVideo;
	videoLink?: IkasNavigationLink;
	titleCDT?: string;
	contentCDT?: string;
	btnTextCDT?: string;
	priorityOrder?: string;
};

export type SlidingSlider = { 
	imageSlider?: IkasImage;
};

export type ShoppingPolicies = { 
	iconSP?: string;
	contentSP?: string;
};

export type SocialMedia = { 
	icon_SM?: string;
	isExternal_SM?: boolean;
	link_SM?: IkasNavigationLink;
};

export type InstallmentContent = { 
	rate: string;
};

export type TableTitles = { 
	table_Header_1: string;
	table_Header_2: string;
	table_Header_3: string;
};

export type InterestRates = { 
	interestRate_1_2: string;
	interestRate_3_6: string;
	interestRate_7_12: string;
};

export type Row = { 
	installmentContent: InstallmentContent;
};

export type AddBank = { 
	logo: IkasImage;
	interestRates: InterestRates;
	content: Row;
};

export type MainTable = { 
	enterTitles: TableTitles;
	enterLogoAndProportions: AddBank;
};

export type FooterLower = { 
	title?: string;
	content?: string;
	btnText?: string;
	btnLink?: IkasNavigationLink;
	qrTitle?: string;
	qrImage?: IkasImage;
	qrContent?: string;
	acceptedCardsTitle?: string;
	acceptedCardsImages?: AcceptedCards;
};

export type AcceptedCards = { 
	acceptedCardsImage?: string;
};

export type FooterTop = { 
	title?: string;
	content?: string;
	langTitle?: string;
};

export type CategorNames = { 
	category_name?: string;
};

export type DiscountBannerCategoryNames = { 
	cat_names?: CategorNames;
	header_text?: string;
	header_color?: string;
	content_text?: string;
	content_color?: string;
	bg_color?: string;
	isColorEffectEnabled?: boolean;
	isTextEffectEnabled?: boolean;
};

export type DeliveryContent = { 
	question?: string;
	answer?: string;
};

export type Campaigns = { 
	isActive?: boolean;
	campaignTitle?: string;
	campaignDate?: string;
	campaignDescription?: string;
	campaignImage?: IkasImage;
	campaignConditions?: string;
	btnText?: string;
	productList?: IkasProductList;
};

export type MessageSubTopic = { 
	topicName?: string;
};

export type MessageTopic = { 
	messageName?: string;
	subTopic?: MessageSubTopic;
};

export type ContactForm = { 
	name?: string;
	messageType?: MessageTopic;
};

export type WorkingHours = { 
	dayName?: string;
	checkInTime?: string;
	checkOutTime?: string;
};

export type ShoppingCentre = { 
	name?: string;
	address?: string;
	phone?: string;
	link?: string;
	workingHours?: WorkingHours;
	isAvm?: boolean;
};

export type District = { 
	districtName?: string;
	districtStores?: ShoppingCentre;
};

export type Province = { 
	provinceName?: string;
	stores?: District;
};

export type Position = { 
	positionName?: string;
};

export type CareerForm = { 
	name?: string;
	departments?: Position;
};

export type PackageBenefits = { 
	title?: string;
	description?: string;
};

export type Packages = { 
	packageImage?: IkasImage;
	packageTitle?: string;
	spendingLimit?: string;
	packageBenefits?: PackageBenefits;
};

export type Localization = { 
	text?: string;
	buttonText?: string;
	backgroundColor?: string;
	color?: string;
};

export type ImageList = { 
	imageWeb?: IkasImage;
	imageMobil?: IkasImage;
	relatedProduct?: IkasProductList;
	customTagText?: string;
	customTagTextColor?: string;
	customTagBgColor?: string;
	isCustomTagLeft?: boolean;
};

export type FreeImageShowcase = { 
	image?: IkasImage;
	relatedProduct?: IkasProduct;
};

export enum SpecialDayEffects{ 
	"isEidEffectActive" = "isEidEffectActive",
	"isNewYearEffectActive" = "isNewYearEffectActive",
	"isValentinesDayEffectActive" = "isValentinesDayEffectActive",
};

export type CustomProductTags = { 
	iconWithTags?: string;
	iconImage?: IkasImage;
	iconTagName?: string;
	width?: IkasSlider;
	widthMobile?: IkasSlider;
};

export type CampaignTags = { 
	badgeWithTagsName?: string;
	badgeIcon?: IkasImage;
	badgeName?: string;
	iconWidthValue?: IkasSlider;
};

export type CampaignTagsMain = { 
	badge?: CampaignTags;
	badgeAlignment?: AlignmentSettings;
	badgeLoopDuration?: IkasSlider;
	badgeAnimation?: AnimationTypes;
	badgeTextColor?: string;
	badgeBgColor1?: string;
	badgeBgColor2?: string;
	badgeFontSize?: IkasSlider;
	badgeMobileFontSize?: IkasSlider;
	badgeHeight?: IkasSlider;
	badgeMobileHeight?: IkasSlider;
};

export enum AnimationTypes{ 
	"Slide up/down" = "Slide up/down",
	"Fade Slow Effect" = "Fade Slow Effect",
};

export enum AlignmentSettings{ 
	"start" = "start",
	"center" = "center",
	"left" = "left",
};

export type HeaderProps = {
	logo?: IkasImage;
	logo_black?: IkasImage;
	staticCategoryMenu?: IkasCategoryList;
	categoryMenu?: IkasCategoryList;
	searchRecomProducts?: IkasProductList;
	special_for_your?: IkasNavigationLink;
	scrollingTexts?: ScrollingTexts[];
	title?: string;
	cartProducts?: IkasProductList;
	showLocalization?: boolean;
	localization?: Localization;
	isShowCustomCategory?: boolean;
	customCategoryName?: string;
};

export type FooterProps = {
	logo?: IkasImage;
	shoppingPolicies?: ShoppingPolicies[];
	socialMediaList?: SocialMedia[];
	supportLinks?: IkasNavigationLink[];
	legalLinks?: IkasNavigationLink[];
	footerLower?: FooterLower;
	footerUpperTop?: FooterTop;
};

export type BannerTopSliderProps = {
	videoList?: BannerTopVideo[];
	videoListMobile?: BannerTopVideo[];
	imageList?: BannerTopImage[];
	imageListMobile?: BannerTopImage[];
};

export type BannerSingleProps = {
	imageWeb?: IkasImage;
	imageMobil?: IkasImage;
	headerText?: string;
	contentText?: string;
	btnText?: string;
	navigationLink?: IkasNavigationLink;
};

export type BannerTrioProps = {
	banner_left?: IkasImage;
	banner_left_link?: IkasNavigationLink;
	banner_right?: IkasVideo;
	banner_right_link?: IkasNavigationLink;
	banner_bg_color?: string;
	banner_center_link?: IkasNavigationLink;
	bannerCenterText?: string;
	bannerCenterTextColor?: string;
	bannerCenterContent?: string;
	bannerCenterContentColor?: string;
	bannerCenterButtonText?: string;
	bannerCenterButtonTextColor?: string;
};

export type FeaturedProductShowcaseProps = {
	products?: IkasProductList;
	headerText?: string;
	titleText?: string;
	contentText?: string;
	btnText?: string;
	btnLink?: IkasNavigationLink;
	isWidthVideo?: boolean;
};

export type BannerSlidingSliderProps = {
	imageSliders?: SlidingSlider[];
	titleBanner?: string;
	lowerTitle?: string;
	lowerContent?: string;
	lowerBtnText?: string;
	lowerBtnLink?: IkasNavigationLink;
};

export type BannerThinProps = {
	banner_center?: IkasImage;
	banner_cente_mobile?: IkasImage;
	banner_center_link?: IkasNavigationLink;
};

export type ProductListProps = {
	categories?: IkasCategoryList;
	productList?: IkasProductList;
	categorNames?: DiscountBannerCategoryNames[];
	isWidthVideo?: boolean;
	tags?: CustomProductTags[];
	alignTagsRight?: boolean;
	campaignList?: CampaignTagsMain;
	showTags?: boolean;
};

export type ProductDetailProps = {
	product?: IkasProduct;
	completeTheLookTitle?: string;
	completeTheLookContent?: string;
	deliveryDescription?: string;
	deliveryDescriptionLink?: IkasNavigationLink;
	bankTable?: MainTable[];
	isWidthVideo?: boolean;
	showVariantStockWarning?: boolean;
	showProductStats?: boolean;
};

export type BottomScrollingTextProps = {
	scrollingTexts?: ScrollingTexts[];
	transitionPeriod?: string;
};

export type BannerTextsProps = {
	webMarginValue?: string;
	mobilMarginValue?: string;
	bgColor?: string;
	headerText?: string;
	contentText?: string;
	btnText?: string;
	navigationLink?: IkasNavigationLink;
};

export type BlogListsProps = {
	isSlider?: boolean;
	bannerTitle?: string;
	blogs?: IkasBlogList;
};

export type BlogDetailProps = {
	blog?: IkasBlog;
};

export type AlternativeProductsProps = {
	alternativeProducts?: IkasProductList;
	isWidthVideo?: boolean;
};

export type LastSeenProductsProps = {
	lastSeenProducts?: IkasProductList;
	isWidthVideo?: boolean;
};

export type CartProps = {
	shpngDscrpText?: string;
	shpngPrcRange?: string;
};

export type Page404Props = {
	image?: IkasImage;
};

export type LoginProps = {
	title?: string;
};

export type RegisterProps = {
	title?: string;
	content?: string;
	image?: IkasImage;
	title2?: string;
};

export type ForgotPasswordProps = {
	title?: string;
};

export type RecoverPasswordProps = {
	title?: string;
};

export type PageSearchProps = {
	productList?: IkasProductList;
};

export type AboutProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	content?: string;
	titleRight?: string;
	contentRight?: string;
	btnRight?: string;
	btnRightLink?: IkasNavigationLink;
};

export type CookiePolicyProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	content?: string;
	titleRight?: string;
	contentRight?: string;
	btnRight?: string;
	btnRightLink?: IkasNavigationLink;
};

export type PrivacyPolicyProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	content?: string;
	titleRight?: string;
	contentRight?: string;
	btnRight?: string;
	btnRightLink?: IkasNavigationLink;
};

export type DistanceSalesAgreementProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	content?: string;
	titleRight?: string;
	contentRight?: string;
	btnRight?: string;
	btnRightLink?: IkasNavigationLink;
};

export type FaqProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	contents?: DeliveryContent[];
	titleRight?: string;
	contentRight?: string;
	btnRight?: string;
	btnRightLink?: IkasNavigationLink;
};

export type ReturnsAndDeliveryProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	titleRight?: string;
	contentRight?: string;
	btnRight?: string;
	btnRightLink?: IkasNavigationLink;
	contents?: DeliveryContent[];
};

export type CampaignsProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	campaigns?: Campaigns[];
};

export type ContactProps = {
	web3FormsAccessKey?: string;
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	formTitle?: string;
	contactForm?: ContactForm[];
	contactInformation?: string;
	mapLink?: string;
};

export type StoresProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	storeList?: Province[];
};

export type CareerProps = {
	web3FormsAccessKey?: string;
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	footer_links?: IkasNavigationLink[];
	formTitle?: string;
	careerForm?: CareerForm[];
	otherInformation?: string;
};

export type BannerSingleVideoProps = {
	videoWeb?: IkasVideo;
	videoMobile?: IkasVideo;
};

export type BannerDuoProps = {
	banner_left?: IkasImage;
	banner_left_link?: IkasNavigationLink;
	banner_right?: IkasVideo;
	banner_right_link?: IkasNavigationLink;
};

export type RewardsProps = {
	title?: string;
	textPicture?: string;
	imageWeb?: IkasImage;
	imageMobile?: IkasImage;
	awardTitle?: string;
	awardContent?: string;
	rewardPackages?: Packages[];
	awardNotes?: string;
	productShowcaseTitle?: string;
	productShowcaseContent?: string;
	showcaseProducts?: IkasProductList;
	productShowcaseBtnLink?: IkasNavigationLink;
	contents?: DeliveryContent[];
	contentsTitle?: string;
	contentsOrientation?: string;
};

export type FloatingButtonsProps = {
	phoneNumber?: string;
	messageText?: string;
	togglePoint?: string;
};

export type WelcomePopupProps = {
	bgImageWeb?: IkasImage;
	bgImageMobile?: IkasImage;
	titleText?: string;
	contentText?: string;
	btnText?: string;
};

export type BannerNewPageDynamicProps = {
	showFullPage?: boolean;
	bannerSelection?: IkasComponentRenderer[];
};

export type BannerImageListProps = {
	imageList?: ImageList[];
	webGapValue?: IkasSlider;
	mobilGapValue?: IkasSlider;
};

export type BannerInstagramPostsProps = {
	access_token?: string;
	title?: string;
	image?: IkasImage;
	posts?: string;
	followers?: string;
};

export type FeaturedFreeImageShowcaseProps = {
	products?: FreeImageShowcase[];
	headerText?: string;
	titleText?: string;
	contentText?: string;
	btnText?: string;
	btnLink?: IkasNavigationLink;
	isWidthVideo?: boolean;
};

export type SideOpeningLastSeenProductsProps = {
	productsYouVisited?: IkasProductList;
	isWidthVideo?: boolean;
};

export type EasyRefundProps = {
	web3FormsAccessKey?: string;
	image?: IkasImage;
	imageMobil?: IkasImage;
	title?: string;
	content?: string;
	otherLinks?: IkasNavigationLink[];
	refundForm?: ContactForm[];
};

export type SpecialDayEffectsProps = {
	effects?: SpecialDayEffects;
};

export type InstagramPostsProps = {
	title?: string;
	instagramMediaLimit?: IkasSlider;
	image?: IkasImage;
	access_token?: string;
};

