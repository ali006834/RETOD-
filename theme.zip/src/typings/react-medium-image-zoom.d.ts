declare module "react-medium-image-zoom" {
  import React from "react";

  interface ZoomProps {
    children: React.ReactNode;
    zoomImg?: React.ImgHTMLAttributes<HTMLImageElement>;
    zoomMargin?: number;
    classDialog?: string;
    wrapElement?: "div" | "span";
    isDisabled?: boolean;
    onZoomChange?: (
      value: boolean,
      data: { event: React.SyntheticEvent | Event }
    ) => void;
  }

  const Zoom: React.FC<ZoomProps>;
  export default Zoom;
}
